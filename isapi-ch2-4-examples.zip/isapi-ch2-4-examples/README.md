# ISAPI Quick-Start Examples (Chapters 2–4)

![Python](https://img.shields.io/badge/python-3.9%2B-blue)
![License](https://img.shields.io/badge/license-MIT-green)
![Protocol](https://img.shields.io/badge/protocol-ISAPI%202.0-orange)
![Status](https://img.shields.io/badge/status-stable-brightgreen)

> Runnable integration examples distilled from the **Hikvision ISAPI Developer Guide**
> (Fixed & 2-Series Smart Network Cameras), Chapters 2–4:
> **Overview → Framework (activation & security) → Quick Start (auth, messages, RTSP, playback, events)**.
>
> Built for **developers and system integrators**: every API node ships with its
> *definition, type, call flow, and a real, executable example* — not just doc excerpts.

[中文说明](README.zh-CN.md)

---

## Why this repo

Reading the protocol PDF tells you *what* an interface is; this repo shows you *how to call it*.
Each function docstring maps back to the document section it implements, and every example is
a complete, copy-paste-runnable script.

## API coverage (19 endpoints)

| # | Endpoint | Method | Auth | What it does | Code |
|---|---|---|---|---|---|
| 1 | `/SDK/activateStatus` | GET | **None** | Query activation status | [`activation.py`](isapi/activation.py) |
| 2 | `/ISAPI/Security/challenge` | POST | – | RSA key exchange (challenge) | [`activation.py`](isapi/activation.py) |
| 3 | `/ISAPI/System/activate` | PUT | – | Set initial password (AES128-ECB) | [`activation.py`](isapi/activation.py) |
| 4 | `/ISAPI/System/deviceInfo` | GET | Digest | Device info / auth sanity check | [`client.py`](isapi/client.py) |
| 5 | `rtsp://…/Streaming/channels/<ID>` | RTSP | Digest | Live preview (6-step flow) | [`rtsp.py`](isapi/rtsp.py) |
| 6 | `/ISAPI/ContentMgmt/record/tracks/<ID>/dailyDistribution` | POST | Digest | Recording calendar | [`ch04_playback.py`](examples/ch04_playback.py) |
| 7 | `/ISAPI/ContentMgmt/search` | POST | Digest | Recording search → `playbackURI` | [`ch04_playback.py`](examples/ch04_playback.py) |
| 8 | `rtsp://…/Streaming/tracks/<ID>/?starttime=…` | RTSP | Digest | Playback (PAUSE / Scale) | [`rtsp.py`](isapi/rtsp.py) |
| 9 | `/ISAPI/Event/notification/alertStream` | GET | Digest | Unsubscribed arming (all events) | [`events.py`](isapi/events.py) |
| 10 | `/ISAPI/System/capabilities` | GET | Digest | System capabilities | [`events.py`](isapi/events.py) |
| 11 | `/ISAPI/Event/notification/subscribeEventCap` | GET | Digest | Subscription capability | [`events.py`](isapi/events.py) |
| 12 | `/ISAPI/Event/notification/subscribeEvent` | POST | Digest | Subscribed arming (7 steps) | [`events.py`](isapi/events.py) |
| 13 | `/ISAPI/Event/notification/subscribeEvent/<ID>` | GET/PUT | Digest | Query / modify subscription | [`events.py`](isapi/events.py) |
| 14 | `/ISAPI/Event/notification/unSubscribeEvent` | PUT | Digest | Cancel subscription | [`events.py`](isapi/events.py) |
| 15 | `/ISAPI/Event/notification/httpHosts/capabilities` | GET | Digest | Listening-host support check | [`events.py`](isapi/events.py) |
| 16 | `/ISAPI/Event/notification/httpHosts` | PUT/GET | Digest | Configure all listening hosts | [`events.py`](isapi/events.py) |
| 17 | `/ISAPI/Event/notification/httpHosts/<hostID>` | PUT/GET | Digest | Configure one listening host | [`events.py`](isapi/events.py) |
| 18 | `/ISAPI/Event/notification/httpHosts/<hostID>/test` | POST | Digest | Connectivity test | [`events.py`](isapi/events.py) |
| 19 | `/ISAPI/Event/notification/httpHosts/<hostID>/uploadCtrl` | – | Digest | Listening timeout params | [`events.py`](isapi/events.py) |

## Quick start

```bash
git clone https://github.com/<your-org>/<your-repo>.git
cd <your-repo>
pip install -r requirements.txt

export ISAPI_HOST=192.168.18.84     # device IP
export ISAPI_USER=admin
export ISAPI_PASS=admin12345

python examples/ch03_activation.py            # activation status / activate
python examples/ch03_ch04_authentication.py   # Digest auth → deviceInfo
python examples/ch04_live_preview.py          # RTSP live preview (10 RTP packets)
python examples/ch04_playback.py              # calendar → search → RTSP playback
python examples/ch04_events.py                # arming / subscription / listening
```

## Project structure

```
├── isapi/                  # reusable minimal SDK
│   ├── client.py           # Digest client + unified ISAPI error model (§3.3.1, §4.2.6)
│   ├── activation.py       # activation trio: RSA-1024 + AES128-ECB, full crypto (§3.2)
│   ├── parsing.py          # XML/JSON/binary/multipart, annotations, capabilities, time, charset (§4.2)
│   ├── rtsp.py             # RTSP client: 401 Digest renegotiation, TCP-interleaved RTP reassembly (§4.3/§4.4)
│   └── events.py           # alertStream / subscribeEvent / httpHosts (§4.5)
├── examples/               # per-chapter runnable use cases
└── docs/                   # mind maps & reading notes
```

## Documentation

- [`docs/api-mindmap.md`](docs/api-mindmap.md) — every API with definition / type / call flow / example
- [`docs/reading-notes.md`](docs/reading-notes.md) — chapter-by-chapter notes on the full developer guide

## Notes & disclaimers

- Default IPs/credentials in examples are the document's sample values — replace with your own.
- Digest authentication is required for every endpoint except `GET /SDK/activateStatus`.
- This project is an independent reading of the public protocol document, for integration
  learning purposes; it is not an official Hikvision SDK.

## License

MIT — see [LICENSE](LICENSE).
