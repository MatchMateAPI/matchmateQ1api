# ISAPI 快速入门示例（第 2~4 章）

> 面向开发者与集成商的可运行示例工程，源自海康威视《ISAPI 开发指南》第 2~4 章。
> 每个 API 节点都包含**定义、类型、调用方式、可执行用例**，不只是文档摘抄。

## 快速开始

```bash
pip install -r requirements.txt
export ISAPI_HOST=192.168.18.84
export ISAPI_USER=admin
export ISAPI_PASS=admin12345

python examples/ch03_activation.py            # 激活状态 / 执行激活
python examples/ch03_ch04_authentication.py   # Digest 认证调通 deviceInfo
python examples/ch04_live_preview.py          # RTSP 实时预览
python examples/ch04_playback.py              # 月历 → 检索 → 回放
python examples/ch04_events.py                # 布防 / 订阅 / 监听
```

完整接口清单与工程说明见 [README.md](README.md)。
